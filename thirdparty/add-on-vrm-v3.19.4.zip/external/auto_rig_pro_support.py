# SPDX-License-Identifier: MIT OR GPL-3.0-or-later

# https://www.lucky3d.fr/auto-rig-pro/doc/ge_export_doc.html#export-by-script
